import React, { useState } from 'react'

export default function Sidebar({ backendJson }) {
  const [open, setOpen] = useState(true)
  const [tab, setTab] = useState('entities')

  // Predefined keys shown in UI
  const predefinedEntityKeys = [
    'bg_currency','crl_currency','currency_matched','bg_amount','crl_amount','amount_matched',
    'bg_expiry_date','crl_expiry_date','expiry_date_matched','bg_claim_expiry_date','crl_claim_expiry_date','claim_expiry_date_matched',
    'bg_applicant_name','crl_applicant_name','applicant_name_matched','bg_beneficiary_name','crl_beneficiary_name','beneficiary_name_matched',
    'bg_issuing_bank_name','crl_issuing_bank_name','issuing_bank_name_matched','bg_type','crl_type','type_matched'
  ]

  function fireSearch(text) {
    window.dispatchEvent(new CustomEvent('bg-search', { detail: { text } }))
  }

  return (
    <aside className={`flex flex-col border-r bg-white transition-all ${open ? 'w-96' : 'w-12'}`}>
      <div className="flex items-center justify-between p-3 border-b">
        <div className="flex items-center space-x-2">
          <button onClick={() => setOpen(s => !s)} className="p-1 rounded hover:bg-gray-100">{open ? '⟨' : '☰'}</button>
          {open && <h3 className="text-sm font-semibold">Sidebar</h3>}
        </div>
        {open && (
          <div className="flex items-center space-x-2">
            <button onClick={() => setTab('entities')} className={`px-2 py-1 rounded ${tab==='entities'?'bg-gray-100':''}`}>Extracted Entities</button>
            <button onClick={() => setTab('clauses')} className={`px-2 py-1 rounded ${tab==='clauses'?'bg-gray-100':''}`}>Onerous Clauses</button>
          </div>
        )}
      </div>

      {open ? (
        <div className="p-3 overflow-auto flex-1">
          {tab === 'entities' && (
            <div>
              <h4 className="text-xs text-gray-500 mb-2">Entities</h4>
              <div className="space-y-2">
                {predefinedEntityKeys.map(k => (
                  <div key={k} className="flex items-center justify-between p-2 border rounded">
                    <div className="text-xs text-gray-600">{k}</div>
                    <div>
                      <button onClick={() => fireSearch(backendJson.processResult.entities[k])} className="text-sm font-medium hover:underline">
                        {backendJson.processResult.entities[k] ?? '-'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'clauses' && (
            <div>
              <h4 className="text-xs text-gray-500 mb-2">Onerous Clauses</h4>
              <div className="flex flex-col space-y-2">
                {backendJson.onerous_clauses.map((c,i) => (
                  <button key={i} onClick={() => fireSearch(c)} className="text-left p-2 border rounded hover:bg-gray-50">{c}</button>
                ))}
              </div>
            </div>
          )}

        </div>
      ) : <div className="flex-1" />}
    </aside>
  )
}
