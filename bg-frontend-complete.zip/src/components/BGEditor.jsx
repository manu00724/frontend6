import React, { useEffect, useRef, useState } from 'react'
import JoditEditor from 'jodit-react'

export default function BGEditor({ backendJson }) {
  const joditRef = useRef(null)
  const [html, setHtml] = useState(backendJson.bgtextHtml || '')

  // Clear previous mark highlights we add (mark[data-bg-highlight])
  function clearHighlightsFromHtml(h) {
    const container = document.createElement('div')
    container.innerHTML = h
    const marks = container.querySelectorAll('mark[data-bg-highlight]')
    marks.forEach(m => {
      const tn = document.createTextNode(m.textContent)
      m.parentNode.replaceChild(tn, m)
    })
    return container.innerHTML
  }

  function highlightFirstMatch(h, searchText) {
    if (!searchText) return h
    const container = document.createElement('div')
    container.innerHTML = h
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null, false)
    let n
    const sLower = searchText.toLowerCase()
    while ((n = walker.nextNode())) {
      const txt = n.nodeValue
      const idx = txt.toLowerCase().indexOf(sLower)
      if (idx >= 0) {
        const before = txt.slice(0, idx)
        const match = txt.slice(idx, idx + searchText.length)
        const after = txt.slice(idx + searchText.length)
        const beforeNode = document.createTextNode(before)
        const mark = document.createElement('mark')
        mark.setAttribute('data-bg-highlight', 'true')
        mark.className = 'mark-highlight'
        mark.textContent = match
        const afterNode = document.createTextNode(after)
        const parent = n.parentNode
        parent.replaceChild(afterNode, n)
        parent.insertBefore(mark, afterNode)
        parent.insertBefore(beforeNode, mark)
        return container.innerHTML
      }
    }
    return h
  }

  function doSearchAndHighlight(text) {
    const cleared = clearHighlightsFromHtml(html)
    const newHtml = highlightFirstMatch(cleared, text)
    setHtml(newHtml)

    setTimeout(() => {
      const root = document.querySelector('.jodit-wysiwyg')
      const mark = root && root.querySelector('mark[data-bg-highlight]')
      if (mark) {
        mark.scrollIntoView({ behavior: 'smooth', block: 'center' })
        mark.style.transition = 'box-shadow 0.25s ease'
        mark.style.boxShadow = '0 0 0 3px rgba(255,235,59,0.5)'
        setTimeout(() => (mark.style.boxShadow = 'none'), 700)
      }
    }, 200)
  }

  useEffect(() => {
    function handler(e) {
      const t = e.detail?.text
      if (t) doSearchAndHighlight(String(t))
    }
    window.addEventListener('bg-search', handler)
    return () => window.removeEventListener('bg-search', handler)
  }, [html])

  useEffect(() => {
    // update editor content when html state changes
    if (joditRef.current && joditRef.current.editor) {
      try {
        joditRef.current.setContent(html)
      } catch (e) {}
    }
  }, [html])

  const config = {
    readonly: false,
    height: 450,
    toolbar: true,
  }

  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">BG Document Editor</h1>
      <div className="mb-3 text-sm text-gray-600">Click a value in the sidebar to search & highlight it inside the editor.</div>
      <JoditEditor ref={joditRef} value={html} config={config} onChange={v => setHtml(v)} />
      <div className="flex justify-end space-x-2 mt-4">
        <button onClick={() => { navigator.clipboard && navigator.clipboard.writeText(html); alert('HTML copied to clipboard') }} className="px-4 py-2 border rounded">Copy HTML</button>
        <button onClick={() => { console.log('Saved HTML:\n', html); alert('Saved (check console)') }} className="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
      </div>
    </div>
  )
}
