import React from 'react'
import BGEditor from './components/BGEditor'
import Sidebar from './components/Sidebar'
import backendJson from './data.json'

export default function App() {
  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar backendJson={backendJson} />
      <main className="flex-1 p-6">
        <div className="max-w-5xl mx-auto">
          <BGEditor backendJson={backendJson} />
        </div>
      </main>
    </div>
  )
}
