import React, { useState, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import JoditEditor from "jodit-react";
import NotificationBox from "../components/NotificationBox";
import Sidebar from "../components/Sidebar";
import Toasts from "../components/Toast";
import ENTITY_KEYS from "../config/entityKeys";

const SAMPLE = {
  processResult: {
    entities: {
      bg_currency: "INR",
      crl_currency: "INR",
      currency_matched: "YES",
      bg_amount: "4750000",
      crl_amount: "4750000",
      amount_matched: "YES",
      bg_expiry_date: "NA",
      crl_expiry_date: "31/03/2025",
      expiry_date_matched: "NO",
      bg_claim_expiry_date: "30/09/2025",
      crl_claim_expiry_date: "NA",
      claim_expiry_date_matched: "NO",
      bg_applicant_name: "Company A",
      crl_applicant_name: "Company A",
      applicant_name_matched: "YES",
      bg_beneficiary_name: "Beneficiary A",
      crl_beneficiary_name: "Beneficiary B",
      beneficiary_name_matched: "NO",
      bg_issuing_bank_name: "Bank A",
      crl_issuing_bank_name: "Bank B",
      issuing_bank_name_matched: "NO",
      bg_type: "Financial Guarantee",
      crl_type: "Performance Guarantee",
      type_matched: "NO"
    },
    warnings: {},
    errors: {
      error_entities: ["expiry_date", "claim_expiry_date", "beneficiary_name", "issuing_bank_name", "type"]
    }
  },
  bgTextHtml:
    "<p>This is sample BG HTML text.</p><p>Amount: 4750000</p><p>Clause 1: The bank shall be liable for all delays.</p><p>Clause 2: Claim payable on first demand.</p><p>Clause 3: No limitation on liability period.</p>",
  onerous_clauses: [
    "Clause 1: The bank shall be liable for all delays.",
    "Clause 2: Claim payable on first demand.",
    "Clause 3: No limitation on liability period."
  ]
};

export default function Dashboard() {
  const location = useLocation();
  const navigate = useNavigate();
  const payload = location.state || SAMPLE;

  const entities = (payload.processResult && payload.processResult.entities) || {};
  const errors = (payload.processResult && payload.processResult.errors && payload.processResult.errors.error_entities) || [];
  const clauses = payload.onerous_clauses || [];
  const [html, setHtml] = useState(payload.bgTextHtml || "");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState("entities");

  const [toasts, setToasts] = useState([]);
  const editorRef = useRef(null);

  function pushToast(message, type = "info", ttl = 3000) {
    const id = "t-" + Date.now() + "-" + Math.floor(Math.random() * 1000);
    const t = { id, message, type };
    setToasts(prev => [t, ...prev]);
    setTimeout(() => removeToast(id), ttl);
  }
  function removeToast(id) {
    setToasts(prev => prev.filter(t => t.id !== id));
  }

  function stripHighlights(inputHtml) {
    return inputHtml.replace(/<span[^>]*data-highlight-id="[^"]*"[^>]*>(.*?)<\/span>/gi, "$1");
  }

  function highlightAllAndScroll(targetText) {
    if (!targetText) return;
    let clean = stripHighlights(html);

    const escapeRegExp = s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const pattern = escapeRegExp(targetText);
    const re = new RegExp(pattern, "gi");

    if (!re.test(clean)) {
      pushToast(`Not found in document: "${targetText}"`, "error", 3500);
      const editorWrap = document.querySelector(".jodit-container") || document.querySelector(".jodit-wysiwyg");
      if (editorWrap) {
        editorWrap.style.boxShadow = "0 0 0 3px rgba(255,165,0,0.15)";
        setTimeout(() => (editorWrap.style.boxShadow = ""), 600);
      }
      return;
    }

    let firstUid = null;
    let idx = 0;
    const newHtml = clean.replace(re, (m) => {
      const uid = "hl-" + Date.now() + "-" + idx++;
      if (!firstUid) firstUid = uid;
      return `<span class="bg-highlight" data-highlight-id="${uid}">${m}</span>`;
    });

    setHtml(newHtml);

    setTimeout(() => {
      const editorRoot = document.querySelector(".jodit-wysiwyg") || document.querySelector(".jodit-wysiwyg_iframe");
      let found = null;
      if (editorRoot) found = editorRoot.querySelector(`[data-highlight-id="${firstUid}"]`);
      if (!found) found = document.querySelector(`[data-highlight-id="${firstUid}"]`);
      if (found && typeof found.scrollIntoView === "function") {
        found.scrollIntoView({ behavior: "smooth", block: "center" });
        found.style.transition = "box-shadow 0.4s";
        found.style.boxShadow = "0 0 8px rgba(0,0,0,0.2)";
        setTimeout(() => (found.style.boxShadow = ""), 700);
      }
      pushToast(`Highlighted ${idx} occurrence${idx > 1 ? "s" : ""}`, "success", 2200);
    }, 150);
  }

  function onEntityClick(value) {
    if (!value) {
      pushToast("No value to search.", "info", 2000);
      return;
    }
    highlightAllAndScroll(String(value));
  }

  function onClauseClick(text) {
    if (!text) {
      pushToast("Clause empty.", "info", 2000);
      return;
    }
    highlightAllAndScroll(text);
  }

  return (
    <>
      <div className="h-screen flex">
        <Sidebar
          open={sidebarOpen}
          setOpen={setSidebarOpen}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          entityKeys={ENTITY_KEYS}
          entities={entities}
          clauses={clauses}
          onEntityClick={onEntityClick}
          onClauseClick={onClauseClick}
        />

        <div className="flex-1 p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="text-xl font-semibold">BG Editor</div>
            <div>
              <button onClick={() => setHtml(stripHighlights(html))} className="px-3 py-1 bg-slate-700 text-white rounded">Clear Highlights</button>
              <button onClick={() => {
                const full = { ...payload, bgTextHtml: html };
                const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(full, null, 2));
                const a = document.createElement("a"); a.href = dataStr; a.download = "processResult.json"; a.click();
              }} className="ml-2 px-3 py-1 bg-green-600 text-white rounded">Download JSON</button>
              <button onClick={() => navigate("/")} className="ml-2 px-3 py-1 border rounded">Back</button>
            </div>
          </div>

          <div className="border rounded">
            <JoditEditor
              ref={editorRef}
              value={html}
              tabIndex={1}
              onBlur={(newContent) => setHtml(newContent)}
              onChange={() => {}}
              config={{ readonly: false, toolbarSticky: false, defaultMode: "wysiwyg", height: 480 }}
            />
          </div>
        </div>

        <NotificationBox errors={errors} />
      </div>

      <Toasts toasts={toasts} onRemove={removeToast} />
    </>
  );
}
