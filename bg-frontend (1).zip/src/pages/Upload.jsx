import React, { useState } from "react";

export default function UploadPage({ onUploadSuccess }) {
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  function handlePasteSubmit(e) {
    e.preventDefault();
    setError("");
    try {
      const parsed = JSON.parse(text);
      onUploadSuccess(parsed);
    } catch (err) {
      setError("Invalid JSON. Please fix and submit.");
    }
  }

  function handleFile(e) {
    setError("");
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        onUploadSuccess(parsed);
      } catch (err) {
        setError("Uploaded file is not valid JSON.");
      }
    };
    reader.readAsText(f);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
      <div className="w-full max-w-3xl bg-white rounded shadow p-6">
        <h2 className="text-2xl font-semibold mb-4">Upload / Paste processResult JSON</h2>

        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Paste JSON</label>
          <form onSubmit={handlePasteSubmit}>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder='Paste JSON like { "processResult": { ... }, "bgTextHtml": "...", "onerous_clauses": [...] }'
              className="w-full h-48 border rounded p-2 text-sm"
            />
            <div className="flex items-center gap-2 mt-2">
              <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded">Load</button>
              <button type="button" onClick={() => { setText(""); setError(""); }} className="px-3 py-2 border rounded">
                Clear
              </button>
            </div>
          </form>
          {error && <div className="mt-2 text-sm text-red-600">{error}</div>}
        </div>

        <div className="mb-2">
          <label className="block text-sm font-medium mb-1">Or upload JSON file</label>
          <input type="file" accept=".json,application/json" onChange={handleFile} />
        </div>

        <div className="text-sm text-gray-600 mt-4">
          After loading, you'll be taken to the editor where you can inspect entities, highlight values and onerous clauses.
        </div>
      </div>
    </div>
  );
}
