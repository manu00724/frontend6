import React from "react";

export default function NotificationBox({ errors = [] }) {
  if (!errors || errors.length === 0) return null;
  return (
    <div className="fixed right-6 bottom-6 max-w-sm z-50">
      <div className="bg-red-600 text-white rounded shadow-lg p-3">
        <div className="font-semibold">Mismatching fields</div>
        <ul className="mt-2 list-disc list-inside text-sm">
          {errors.map((e, i) => (
            <li key={i}>{e}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
