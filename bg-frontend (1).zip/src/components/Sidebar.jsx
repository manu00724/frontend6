import React from "react";

export default function Sidebar({
  open,
  setOpen,
  activeTab,
  setActiveTab,
  entityKeys = [],
  entities = {},
  clauses = [],
  onEntityClick,
  onClauseClick
}) {
  return (
    <div className={`transition-all duration-200 ${open ? "w-96" : "w-12"} bg-gray-50 border-r`}>
      <div className="flex items-center justify-between p-2 border-b">
        <div className="text-sm font-semibold px-2">Sidebar</div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveTab("entities")}
            className={`px-3 py-1 rounded ${activeTab === "entities" ? "bg-white shadow" : "text-gray-500"}`}
          >
            Entities
          </button>
          <button
            onClick={() => setActiveTab("clauses")}
            className={`px-3 py-1 rounded ${activeTab === "clauses" ? "bg-white shadow" : "text-gray-500"}`}
          >
            Clauses
          </button>
          <button onClick={() => setOpen(s => !s)} className="ml-2 px-2 py-1 rounded bg-white shadow text-sm" title="Toggle sidebar">
            {open ? "«" : "»"}
          </button>
        </div>
      </div>

      {open && (
        <div className="p-3 overflow-auto" style={{ height: "calc(100% - 48px)" }}>
          {activeTab === "entities" ? (
            <div>
              <h3 className="font-medium mb-2">Extracted Entities</h3>
              <div className="space-y-2">
                {entityKeys.map(({ key, label }) => (
                  <div key={key} className="flex items-center justify-between bg-white p-2 rounded shadow-sm">
                    <div className="text-sm text-gray-600">{label}</div>
                    <div>
                      <button
                        onClick={() => onEntityClick(entities[key])}
                        className="text-blue-600 hover:underline"
                      >
                        {entities[key] ?? "—"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div>
              <h3 className="font-medium mb-2">Onerous Clauses</h3>
              <div className="space-y-2">
                {(clauses.length ? clauses : ["(no clauses)"]).map((c, idx) => (
                  <div key={idx} className="bg-white p-2 rounded shadow-sm flex items-start">
                    <div className="flex-1 text-sm">{c}</div>
                    <div>
                      <button onClick={() => onClauseClick(c)} className="text-blue-600 hover:underline text-sm">Find</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
