import React from "react";

export default function Toasts({ toasts = [], onRemove }) {
  return (
    <div className="fixed right-6 top-6 z-50 flex flex-col gap-2">
      {toasts.map(t => (
        <div
          key={t.id}
          className={`rounded shadow px-4 py-2 text-sm ${t.type === "error" ? "bg-red-600 text-white" : t.type === "success" ? "bg-green-600 text-white" : "bg-slate-800 text-white"}`}
        >
          <div className="flex items-start justify-between gap-4">
            <div>{t.message}</div>
            <button onClick={() => onRemove(t.id)} className="ml-2 opacity-80">✕</button>
          </div>
        </div>
      ))}
    </div>
  );
}
