import React from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import UploadPage from "./pages/Upload";
import Dashboard from "./pages/Dashboard";

function UploadWrapper() {
  const navigate = useNavigate();
  return <UploadPage onUploadSuccess={(data) => navigate("/editor", { state: data })} />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<UploadWrapper />} />
      <Route path="/editor" element={<Dashboard />} />
    </Routes>
  );
}
