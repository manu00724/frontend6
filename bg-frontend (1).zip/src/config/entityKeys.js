const ENTITY_KEYS = [
  { key: "bg_currency", label: "BG Currency" },
  { key: "crl_currency", label: "CRL Currency" },
  { key: "bg_amount", label: "BG Amount" },
  { key: "crl_amount", label: "CRL Amount" },
  { key: "bg_expiry_date", label: "BG Expiry Date" },
  { key: "crl_expiry_date", label: "CRL Expiry Date" },
  { key: "bg_claim_expiry_date", label: "BG Claim Expiry Date" },
  { key: "crl_claim_expiry_date", label: "CRL Claim Expiry Date" },
  { key: "bg_applicant_name", label: "BG Applicant Name" },
  { key: "crl_applicant_name", label: "CRL Applicant Name" },
  { key: "bg_beneficiary_name", label: "BG Beneficiary Name" },
  { key: "crl_beneficiary_name", label: "CRL Beneficiary Name" },
  { key: "bg_issuing_bank_name", label: "BG Issuing Bank" },
  { key: "crl_issuing_bank_name", label: "CRL Issuing Bank" },
  { key: "bg_type", label: "BG Type" },
  { key: "crl_type", label: "CRL Type" }
];

export default ENTITY_KEYS;
